# Sistem Inspeksi Visual PCB Berbasis OpenCV

Program tugas akhir untuk inspeksi visual pemasangan komponen pada PCB menggunakan kamera Logitech C920 dan OpenCV.

## Fitur Utama

- Akuisisi citra webcam Logitech C920
- Multi-scale template matching
- Deteksi komponen C1, C2, CONNECTOR, CRYSTAL, DIODA, dan IC
- Pemeriksaan komponen hilang
- Pengukuran pergeseran posisi
- Pengukuran kemiringan komponen
- Stabilisasi hasil antar-frame
- Dua profil JIG dan referensi terpisah
- Alarm suara saat kondisi NOT GOOD
- Auto-capture
- Penyimpanan citra, JSON, TXT, CSV, dan Excel
- Penyimpanan dataset pembelajaran

## Metode Computer Vision

Program menggunakan beberapa fungsi OpenCV, antara lain:

- Grayscale
- Gaussian Blur
- CLAHE
- Canny Edge Detection
- Morphological Closing
- Multi-scale Template Matching dengan `cv2.TM_CCOEFF_NORMED`
- Region of Interest (ROI)
- Intersection over Union (IoU)
- `minAreaRect`
- `HoughLinesP`
- PCA untuk estimasi orientasi
- Median dan exponential smoothing

## Parameter Utama

- Resolusi kamera: 640 × 480
- Target FPS: 30 FPS
- Matching threshold: 0.58
- Skala template: 0.70, 0.80, 0.90, 1.00, 1.10, 1.20, 1.30
- Minimum deteksi stabil: 4 frame
- Hold missing: 6 frame
- Batas kemiringan: 15°
- Minimum toleransi pergeseran: 8 px
- Rasio toleransi pergeseran: 18% diagonal bounding box

## Struktur Folder

```text
pcb-visual-inspection-opencv/
├── deteksi_pcb.py
├── gambar_input/
├── requirements.txt
├── .gitignore
└── README.md
```

Folder `gambar_input` diisi dengan template komponen sesuai penamaan yang digunakan program.

Contoh:

```text
C1 GOOD.png
C2 GOOD.png
Connector GOOD.png
Connector NOT GOOD.png
Crystal GOOD.png
Dioda GOOD.png
Dioda NOT GOOD.png
IC GOOD.png
```

## Instalasi

Gunakan Python 3.10 atau versi yang kompatibel.

```bash
pip install -r requirements.txt
```

## Menjalankan Program

```bash
python deteksi_pcb.py
```

## Kontrol Keyboard

| Tombol | Fungsi |
|---|---|
| `1` | Pilih JIG 1 |
| `2` | Pilih JIG 2 |
| `K` | Simpan referensi GOOD JIG aktif |
| `Z` | Hapus referensi JIG aktif |
| `R` | Reload template dan referensi |
| `C` | Capture manual |
| `M` | Mute/unmute alarm |
| `U` | Buka kunci auto-capture |
| `Q` | Keluar dari program |
| Panah ↑ / ↓ | Scroll rincian komponen |

## Catatan Random Forest

File program yang disertakan pada repository ini **belum memuat implementasi `RandomForestClassifier`, pemanggilan model `.pkl`, atau fungsi `predict()` dari scikit-learn**. Program utama yang tersedia saat ini menjalankan inspeksi berbasis OpenCV dan aturan keputusan.

Jika Random Forest akan dijadikan bagian dari implementasi final tugas akhir, tambahkan:
1. script training Random Forest,
2. dataset fitur training/testing,
3. file model hasil training, dan
4. integrasi `predict()` pada program inspeksi.

## Perangkat

- Webcam Logitech C920
- Laptop ASUS TUF Gaming A15
- Ring LED 12 VDC
- JIG PCB

## Penulis

Ardi Maulana  
D4 Teknik Elektronika  
Politeknik Negeri Padang
